#parse("File Header.java")
public enum ${NAME} {
}
